var myApp = angular.module('myApp', []);

myApp.controller('UserController', ['$scope', function($scope) {
	$scope.username = 'не известно';
	
	$scope.reset = function() {
        $scope.username = '';
    };
}]);
